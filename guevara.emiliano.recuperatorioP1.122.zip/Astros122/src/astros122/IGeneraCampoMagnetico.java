
package astros122;


public interface IGeneraCampoMagnetico {
    void generarCampoMagnetico();
}
