
package astros122;


public class Astros122 {


    public static void main(String[] args) {
        SistemaAstros sistema = new SistemaAstros();
        
        try {
            Astro estrella = new Estrella(5800.0, "Helion", "Sector A", "Estrella", TipoRadiacion.INFRARROJA);
            Astro planeta = new Planeta(true, "Gaia", "Sector B", "Planeta", TipoRadiacion.ULTRAVIOLETA);
            Astro cometa = new Cometa(12, "Xyron", "Sector C", "Cometa", TipoRadiacion.RAYOS_X);

            sistema.agregarAstro(estrella);
            sistema.agregarAstro(planeta);
            sistema.agregarAstro(cometa);

            System.out.println("\n--- Astros registrados correctamente ---\n");

        } catch (AstroInvalidoException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
        
        //Registro de duplicado
        try {
            Astro duplicado = new Estrella(5800.0, "Helion", "Sector A", "Estrella", TipoRadiacion.INFRARROJA);
            sistema.agregarAstro(duplicado);
        } catch (AstroInvalidoException ex) {
            System.out.println("\n[ERROR ESPERADO - Duplicado]\n" + ex.getMessage());
        }
        
        //Registrado de un nulo
        try {
            sistema.agregarAstro(null);
        } catch (AstroInvalidoException ex) {
            System.out.println("\n[ERROR ESPERADO - Objeto nulo]\n" + ex.getMessage());
        }
        
        //Mostrar astros
        System.out.println("\n==============================================");
        System.out.println("\n===== LISTA DE ASTROS =====");
        sistema.mostrarAstros();
        
        //Generar campos magneticos
        System.out.println("\n==============================================");
        try {
            System.out.println("\n===== GENERAR CAMPOS MAGNETICOS =====");
            sistema.generarCamposMagneticos();
        } catch (AccionNoPermitidaException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
        
        //Modificar Orbitas
        System.out.println("\n==============================================");
        try {
            System.out.println("\n===== MODIFICAR ORBITAS =====");
            sistema.modificarOrbitas();
        } catch (AccionNoPermitidaException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
        
        //Filtrado por tipo de radiacion
        System.out.println("\n==============================================");
        System.out.println("\n===== FILTRO: Radiacion ULTRAVIOLETA =====");
        sistema.filtrarPorTipoRadiacion(TipoRadiacion.ULTRAVIOLETA);
        System.out.println("\n===== FILTRO: Radiacion INFRARROJA=====");
        sistema.filtrarPorTipoRadiacion(TipoRadiacion.INFRARROJA);
        System.out.println("\n===== FILTRO: Radiacion RAYOS X=====");
        sistema.filtrarPorTipoRadiacion(TipoRadiacion.RAYOS_X);
        
        //Filtrado por tipo de astro
       System.out.println("\n==============================================");
        System.out.println("\n===== FILTRO: Tipo Estrella =====");
        sistema.filtrarPorTipoDeAstro("Estrella");
        System.out.println("\n===== FILTRO: Tipo Planeta =====");
        sistema.filtrarPorTipoDeAstro("Planeta");
        System.out.println("\n===== FILTRO: Tipo Cometa =====");
        sistema.filtrarPorTipoDeAstro("Cometa");
    }
    
}
