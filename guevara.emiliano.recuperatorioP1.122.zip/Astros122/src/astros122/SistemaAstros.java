
package astros122;

import java.util.ArrayList;
import java.util.List;


public class SistemaAstros {
    private List<Astro> astros;

    public SistemaAstros() {
        this.astros = new ArrayList<>();
    }
    
    public void agregarAstro(Astro astro) throws AstroInvalidoException{
        if(astro == null){
            throw new AstroInvalidoException("El astro no debe ser nulo.");
        }
        for(Astro a : astros){
            if(a.equals(astro)){
                throw new AstroInvalidoException(
                    "Ya existe un astro con el nombre " + a.getNombre() +
                    " en la region " + a.getRegion() + ".");
            }
        }
        astros.add(astro);
    }
    
    public void mostrarAstros(){
        if(astros.isEmpty()){
            System.out.println("No existen astros en el sistema");
        }
        for(Astro astro : astros){
            System.out.println(astro.toString());
        }
    }
    
    public void generarCamposMagneticos() throws AccionNoPermitidaException {
        boolean huboError = true;
        for (Astro a : astros) {
            if (a instanceof IGeneraCampoMagnetico) {
                ((IGeneraCampoMagnetico) a).generarCampoMagnetico();
                huboError = false;
            }
        }
        if (huboError) {
            throw new AccionNoPermitidaException("Hay astros incapaces de generar campo magnetico.");
        }
    }
    
    public void modificarOrbitas() throws AccionNoPermitidaException {
        boolean huboError = true;
        for (Astro a : astros) {
            if (a instanceof IModificaOrbita) {
                ((IModificaOrbita) a).modificarOrbita();
                huboError = false;
            }
        }
        if (huboError) {
            throw new AccionNoPermitidaException("Hay astros incapaces de modificar su orbita.");
        }
    }
    
    public void filtrarPorTipoRadiacion(TipoRadiacion tipoRadiacion){
        boolean encontrado = false;
        for(Astro astro : astros){
            if(astro.getTipoRadiacion().equals(tipoRadiacion)){
                System.out.println(astro.toString());
                encontrado = true;
            }
        }
        if(!encontrado){
            System.out.println("No se han encontrado astros con el tipo de radiacion " + tipoRadiacion);
        }
    }
    
    public void filtrarPorTipoDeAstro(String tipo){
        boolean encontrado = false;
        for(Astro astro : astros){
            if(astro.getTipoAstro().equals(tipo)){
                System.out.println(astro.toString());
                encontrado = true;
            }
        }
        if(!encontrado){
            System.out.println("No se han encontrado astros del tipo: " + tipo);
        }
    }
}
