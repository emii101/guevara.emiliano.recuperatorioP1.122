
package astros122;


public enum TipoRadiacion {
    INFRARROJA,
    ULTRAVIOLETA,
    RAYOS_X
}
