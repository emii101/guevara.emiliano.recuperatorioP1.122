
package astros122;

public class Estrella extends Astro implements IGeneraCampoMagnetico, IModificaOrbita{
    private double temperaturaKelvin;

    public Estrella(double temperaturaKelvin, String nombre, String region, String tipoAstro, TipoRadiacion tipoRadiacion) {
        super(nombre, region, tipoAstro, tipoRadiacion);
        this.temperaturaKelvin = temperaturaKelvin;
    }

    @Override
    public void generarCampoMagnetico() {
        System.out.println(getNombre() + " esta generando un campo magnetico.");
    }

    @Override
    public void modificarOrbita() {
        System.out.println(getNombre() + " ha ajustado su orbita.");
    }
    
    @Override
    public String toString() {
        return super.toString() +
               " | Tipo: Estrella" +
               " | Temp Superficial: " + temperaturaKelvin;
    }
    
    
}
