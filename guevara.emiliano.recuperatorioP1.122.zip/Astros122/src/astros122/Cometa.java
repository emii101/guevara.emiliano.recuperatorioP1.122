
package astros122;


public class Cometa extends Astro implements IModificaOrbita{

    private int periodoOrbital;

    public Cometa(int periodoOrbital, String nombre, String region, String tipoAstro, TipoRadiacion tipoRadiacion) {
        super(nombre, region, tipoAstro, tipoRadiacion);
        this.periodoOrbital = periodoOrbital;
    }

    @Override
    public void modificarOrbita() {
        System.out.println(getNombre() + " ha modificado su orbita.");
    }
    
    @Override
    public String toString() {
        return super.toString() +
               " | Tipo: Cometa" +
               " | Periodo orbital: " + periodoOrbital + " anios";
    }
}
