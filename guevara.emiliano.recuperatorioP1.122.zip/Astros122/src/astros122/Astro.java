
package astros122;


public abstract class Astro {
    private String nombre;
    private String region;
    private String tipoAstro;
    private TipoRadiacion tipoRadiacion;

    public Astro(String nombre, String region, String tipoAstro, TipoRadiacion tipoRadiacion) {
        this.nombre = nombre;
        this.region = region;
        this.tipoAstro = tipoAstro;
        this.tipoRadiacion = tipoRadiacion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getRegion() {
        return region;
    }

    public TipoRadiacion getTipoRadiacion() {
        return tipoRadiacion;
    }

    public String getTipoAstro() {
        return tipoAstro;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Astro)) return false;
        Astro other = (Astro) obj;
        return this.nombre.equalsIgnoreCase(other.nombre) &&
               this.region.equalsIgnoreCase(other.region);
    }

    @Override
    public String toString() {
        return "Astro: " + nombre +
               " | Region: " + region +
               " | Radiacion: " + tipoRadiacion;
    }
    
}
