
package astros122;


public class Planeta extends Astro implements IGeneraCampoMagnetico{
    private boolean tieneAtmosfera;

    public Planeta(boolean tieneAtmosfera, String nombre, String region, String tipoAstro, TipoRadiacion tipoRadiacion) {
        super(nombre, region, tipoAstro, tipoRadiacion);
        this.tieneAtmosfera = tieneAtmosfera;
    }

    @Override
    public void generarCampoMagnetico() {
        System.out.println(getNombre() + " esta generando su campo magnetico.");
    }
    
    @Override
    public String toString() {
        return super.toString() +
               " | Tipo: Planeta" +
               " | Tiene atmosfera: " + (tieneAtmosfera ? "Si" : "No");
    }
}
