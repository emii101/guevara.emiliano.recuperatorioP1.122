
package astros122;


public class AccionNoPermitidaException extends Exception {
    public AccionNoPermitidaException(String msg) {
        super(msg);
    }
}
