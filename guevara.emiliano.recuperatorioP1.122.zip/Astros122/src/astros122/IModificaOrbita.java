
package astros122;


public interface IModificaOrbita {
    void modificarOrbita();
}
