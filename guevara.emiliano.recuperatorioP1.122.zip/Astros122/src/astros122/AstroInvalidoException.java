
package astros122;


public class AstroInvalidoException extends Exception {
    public AstroInvalidoException(String msg) {
        super(msg);
    }
}
